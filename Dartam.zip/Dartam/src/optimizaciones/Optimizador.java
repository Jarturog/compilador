package optimizaciones;

public class Optimizador {
    // ···
}
