package genCodigoMaquina;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Stack;

import genCodigoIntermedio.GeneradorCIntermedio;
import genCodigoIntermedio.EntradaProcedure;
import genCodigoIntermedio.EntradaVariable;
import analizadorSintactico.ParserSym;

public class GeneradorCMaquina {
    // ···
}